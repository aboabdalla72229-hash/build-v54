# SurveyQuant V33 - بناء APK

هذه النسخة مضبوطة على Target SDK 33 ونسخة التطبيق 1.0.36، ومتصلة بواجهة Railway:
https://surveyquant-backend-production.up.railway.app/api

للبناء من GitHub Actions:
1. ارفع مجلد المشروع إلى Repository جديد.
2. افتح تبويب Actions.
3. شغّل Build SurveyQuant APK.
4. بعد انتهاء البناء افتح الـ workflow ثم Artifacts.
5. نزّل SurveyQuant-v33-APK.

ملاحظة: الـ APK الناتج Debug وموقّع تلقائياً، ومناسب للتثبيت والتجربة والتوزيع المباشر. للنشر على Google Play نحتاج لاحقاً مفتاح توقيع Release مستقل.
