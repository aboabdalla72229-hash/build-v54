# SurveyQuant v1.0.36 - API 33

هذه النسخة تحتوي على إصلاح حفظ الملفات من داخل Android WebView باستخدام MediaStore، وتحسين PDF → DXF باستخدام PDF.js مع DXF R12، بالإضافة إلى Workflow جاهز لبناء APK عبر GitHub Actions.

## بناء APK بدون كمبيوتر
1. ارفع المشروع بالكامل إلى GitHub.
2. افتح تبويب Actions.
3. اختر **Build SurveyQuant API 33 APK**.
4. اضغط **Run workflow**.
5. بعد انتهاء البناء افتح الـ workflow ثم قسم **Artifacts**.
6. نزّل `SurveyQuant-API33-v1.0.36`.

## مكان الملفات المحفوظة على الهاتف
الملفات التي ينشئها التطبيق تُحفظ في:
`Downloads/SurveyQuant`

## ملاحظة PDF → DXF
التحويل المحسن يعمل على ملفات PDF المتجهة Vector. ملفات PDF التي هي مجرد صور ممسوحة ضوئيًا تحتاج لاحقًا إلى Raster-to-Vector/OCR حتى تتحول إلى خطوط CAD حقيقية.
